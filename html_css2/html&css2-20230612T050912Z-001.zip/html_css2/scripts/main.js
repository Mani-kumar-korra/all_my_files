var myHeading = document.querySelector('h1');
myHeading.textContent = 'Hello world!';